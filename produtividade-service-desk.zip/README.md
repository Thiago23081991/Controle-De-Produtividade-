
# Produtividade Service Desk

Ferramenta para gestão e análise de produtividade da equipe de atendimento, permitindo o registro manual de casos e fornecendo insights via Inteligência Artificial.

## 🚀 Configuração do Banco de Dados (Supabase)

Para que o sistema salve os dados, você precisa criar a estrutura no seu projeto Supabase.

1. Acesse seu projeto: `https://supabase.com/dashboard/project/vegxbxzitlvlbaljkbhz`
2. Vá no menu **SQL Editor**.
3. Crie uma **New Query**.
4. Copie o conteúdo do arquivo `supabase_setup.sql` deste projeto.
5. Cole no editor e clique em **Run**.

Isso criará a tabela `productivity_records` e liberará o acesso.

## Funcionalidades

- **Gestão de Produtividade**:
  - Registro de casos "Tratados" (em andamento) e "Finalizados".
  - Definição e acompanhamento de **Metas** individuais.
  - Checkbox para sinalizar **Casos Urgentes** (🚨).
  - Campo de observação para justificativas (Atestados, falhas, etc.).
  - Chat direto entre Expert e Supervisão.

- **Indicadores Visuais**:
  - Cálculo automático de eficiência (%).
  - Destaque para **Top Performer** (🏆).
  - Indicador de **Meta Batida** (🎯).
  - Gráfico de barras comparativo (Tratado vs Finalizado vs Meta).

- **Inteligência Artificial (Gemini)**:
  - Geração de resumos executivos detalhados.
  - Análise de performance e pontos de atenção.

## Tecnologias Utilizadas

- **Frontend**: React 19, TypeScript, Tailwind CSS.
- **Backend**: Supabase (PostgreSQL).
- **AI**: Google GenAI SDK (Gemini 2.5 Flash).
- **Ícones**: Lucide React.

## Credenciais

As credenciais do projeto já estão configuradas no código para conectar ao projeto `vegxbxzitlvlbaljkbhz`.
